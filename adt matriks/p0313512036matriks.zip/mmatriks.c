/* Nama / NIM	: Riva Syafri Rachmatullah / 13512036				*/
/* Nama File	: mmatriks.c										*/
/* Topik		: ADT MATRIKS 										*/
/* Tanggal		: 10 Oktober 2013									*/
/* Deskripsi	: DRIVER ADT MATRIKS								*/

#include "matriks.h"

int main () {
	/* Kamus */
	MATRIKS M1, M2;
	int NBar1, NKol1, NBar2, NKol2;
	int pil;
	
	/* Algoritma */
	printf("Matriks 1\n");
	printf("Ukuran efektif baris (%d-%d) = ", BrsMin, BrsMax); //Asumsi: Masukan ukuran baris selalu benar
	scanf("%d",&NBar1);
	printf("Ukuran efektif kolom (%d-%d) = ", KolMin, KolMax); //Asumsi: Masukan ukuran kolom selalu benar
	scanf("%d",&NKol1);
	BacaMATRIKS(&M1,NBar1,NKol1);
	TulisMATRIKS(M1);
	
	printf("Matriks 2\n");
	printf("Ukuran efektif baris (%d-%d) = ", BrsMin, BrsMax); //Asumsi: Masukan ukuran baris selalu benar
	scanf("%d",&NBar2);
	printf("Ukuran efektif kolom (%d-%d) = ", KolMin, KolMax); //Asumsi: Masukan ukuran kolom selalu benar
	scanf("%d",&NKol2);
	BacaMATRIKS(&M2,NBar2,NKol2);
	TulisMATRIKS(M2);
	
	printf("Pilihan menu (1-4) = "); 
	scanf("%d",&pil); //Asumsi: masukan pilihan selalu benar
	switch (pil) {
		case 1 : 	printf("Hasil penjumlahan 2 matriks\n");
					if (EQSize(M1,M2)) {
						TulisMATRIKS(Plus(M1,M2));
					} else {
						printf("Ukuran matriks tidak sama, tidak bisa dijumlahkan\n");
					}
					break;
		case 2 :	printf("Hasil perkalian 2 matriks\n");
					if (GetNKolEff(M1) == GetNBrsEff(M2)) {
						TulisMATRIKS(Kali2Matriks(M1,M2));
					} else {
						printf("Ukuran efektif kolom matriks 1 tidak sama dengan ukuran efektif baris matriks 2, tidak bisa dikalikan\n");
					}
					break;
		case 3 : 	if (IsBujurSangkar(M1)) {
						printf("Matriks 1 adalah matriks bujur sangkar\n");
					} else {
						printf("Matriks 1 bukan matriks bujur sangkar\n");
					}
					if (IsSymetri(M1)) {
						printf("Matriks 1 adalah matriks simetris\n");
					} else {
						printf("Matriks 1 bukan matriks simetris\n");
					}
					if (IsSparse(M1)) {
						printf("Matriks 1 adalah matriks sparse\n");
					} else {
						printf("Matriks 1 bukan matriks sparse\n");
					}
					break;
		case 4 : 	printf("Hasil transpose matriks 2\n");
					Transpose(&M2);
					TulisMATRIKS(M2);
					break;
	}
	
	return 0;
}