/* NIM / Nama	: 13512036 / Riva Syafri Rachmatullah 				*/
/* Nama File	: mqueue.c 											*/
/* Topik		: ADT QUEUE 										*/
/* Tanggal		: 17 Oktober 2013									*/
/* Deskripsi	: DRIVER ADT QUEUE									*/

/*	File Include */
#include "queue.h"
#include "boolean.h"
#include <stdio.h>
#include <string.h>

/*	Deklarasi tipe string */
typedef char string[5];

/*	Konstanta Universal */
const string add="add";
const string del="del";
const string Exit="exit";

/*	Program Utama */
int main () {
	/* Kamus */
	Queue Q;
	int N,i=0;
	string op;
	infotype nilai;
	boolean exit=false;
	float total=0,rata;
	/* Algoritma */
	printf("Ukuran Queue: ");
	scanf("%d",&N); /* Asumsi input user selalu positif */
	CreateEmpty(&Q,N);
	while (!exit) {
		scanf("%s",&op);
		if (strcmp(op,add)==0) {
			scanf("%f",&nilai);
			Add(&Q,nilai);
		} else if (strcmp(op,del)==0) {
			Del(&Q,&nilai);
			total+=nilai;
			i++;
		} else if (strcmp(op,Exit)==0) {
			exit=true;
		}
	}
	printf("Jumlah elemen tersisa: %d\n",NBElmt(Q));
	if (i==0) {
		rata=0;
		printf("Rata-rata pemrosesan: %.0f\n",rata);
	} else {
		rata=total/i;
		printf("Rata-rata pemrosesan: %.2f\n",rata);
	}
	DeAlokasi(&Q);
}

