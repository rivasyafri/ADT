/* NIM / Nama	: 13512036 / Riva Syafri Rachmatullah				*/
/* Nama File	: mstack.c											*/
/* Topik		: ADT STACK - Statis								*/
/* Tanggal		: 17 Oktober 2013									*/
/* Deskripsi	: DRIVER ADT STACK 									*/

/* File include */
#include <stdio.h>
#include "boolean.h"
#include "stack.h"

/*	Header Prosedur */
void TulisStack (Stack S);
/*	Menuliskan isi S ke layar dari top ke bottom secara horizontal 
	dengan hanya memanfaatkan operasi-operasi dasar stack
	I.S.	: S terdefinisi, mungkin kosong
	F.S.	: Isi S tertulis di layar dari top ke bottom. Di akhir
			  penulisan, S kembali ke kondisi I.S.
			  Jika S kosong, tuliskan "Stack kosong" */

void FilterStack (Stack *S);
/*	I.S.	: Stack S terdefinisi dan tidak kosong
	F.S.	: S berisi hanya elemen vokal (baik huruf besar 
			  ataupun kecil), semua elemen huruf konsonan dibuang
			  Urutan elemen S sesuai urutan semula S tanpa elemen
			  konsonan */

/*	Program Utama */
int main () {
	/* Kamus */
	infotype X;
	Stack S;
	int i=0;
	/* Algoritma */
	CreateEmpty(&S);
	printf("Masukkan isi stack:\n");
	scanf("%c",&X);
	while ((X!='#')&&(i<MaxEl)) {
		Push(&S,X);
		if (i<MaxEl-1) {	
			scanf("\n%c",&X);
		}
		i++;
	}
	TulisStack(S);
	if (!IsEmpty(S)) {
		printf("Setelah dibuang semua konsonan:\n");
		FilterStack(&S);
		TulisStack(S);
	} else {
		printf("Tidak dapat difilter\n");
	}
	return 0;
}

/*	Realisasi Prosedur */
void TulisStack (Stack S) {
	/* Kamus */
	infotype X; 
	/* Algoritma */
	if (IsEmpty(S)) {
		printf("Stack kosong");
	} else {
		while (!IsEmpty(S)) {
			Pop(&S,&X);
			printf("%c",X);
		}
	}
	printf("\n");
}

void FilterStack (Stack *S) {
	/* Kamus */
	Stack Stemp;
	infotype x;
	/* Algoritma */
	CreateEmpty(&Stemp);
	while (!IsEmpty(*S)) {
		Pop(S,&x);
		if ((x=='a')||(x=='e')||(x=='i')||(x=='o')||(x=='u')||
			(x=='A')||(x=='E')||(x=='I')||(x=='O')||(x=='U')) {
			Push(&Stemp,x);
		}
	}
	while (!IsEmpty(Stemp)) {
		Pop(&Stemp,&x);
		Push(S,x);
	}
}
